# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['demo']

package_data = \
{'': ['*']}

install_requires = \
['pendulum>=1.4.4']

extras_require = \
{'bar': ['tomlkit'], 'foo': ['cleo']}

setup_kwargs = {
    'name': 'demo',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Sébastien Eustace',
    'author_email': 'sebastien@eustace.io',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=2.7, !=3.0.*, !=3.1.*, !=3.2.*, !=3.3.*',
}


setup(**setup_kwargs)
