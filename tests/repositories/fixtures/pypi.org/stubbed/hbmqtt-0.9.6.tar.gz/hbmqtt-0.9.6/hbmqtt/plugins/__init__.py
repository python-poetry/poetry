# Copyright (c) 2015 Nicolas JOUANIN
#
# See the file license.txt for copying permission.
