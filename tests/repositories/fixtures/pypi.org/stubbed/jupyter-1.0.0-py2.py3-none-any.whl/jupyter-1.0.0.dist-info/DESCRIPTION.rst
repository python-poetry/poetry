Install the Jupyter system, including the notebook, qtconsole, and the IPython kernel.


