from __future__ import annotations

import sys


WINDOWS = sys.platform == "win32"
