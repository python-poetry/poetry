from __future__ import annotations


class PoetryCoreError(Exception):
    pass
