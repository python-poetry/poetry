Original Creator & Maintainer
===================
- Timothy Edmund Crosley (@timothycrosley)

Plugin Writers
===================
- *VIM* - Juan Pedro Fisanotti (@fisadev)
- *Emacs* - Friedrich Paetzke (@paetzke)
- *Sublime* - Thijs de Zoute (@thijsdezoete)

Notable Bug Reporters
===================
- Bengt Lüers (@Bengt)
- Chris Adams (@acdha)
- @OddBloke
- Martin Geisler (@mgeisler)
- Tim Heap (@timheap)

Code Contributors
===================
- Aaron Gallagher (@habnabit)
- Thomas Grainger (@graingert)
- Thijs de Zoute (@thijsdezoete)
- Marc Abramowitz (@msabramo)
- Daniel Cowgill (@dcowgill)
- Francois Lebel (@flebel)
- Antoni Segura Puimedon (@celebdor)
- Pablo (@oubiga)
- Oskar Hahn (@ostcar)
- Wim Glenn (@wimglenn)
- Matt Caldwell (@mattcaldwell)
- Dwayne Bailey (@dwaynebailey)
- Ionel Cristian Mărieș (@ionelmc)
- Chris Adams (@acdha)
- GuoJing (@GuoJing)
- George Hickman (@ghickman)
- Dan Davison (@dandavison)
- Maciej Wolff (@maciejwo)
- Elliott Sales de Andrade (@qulogic)
- Kasper Jacobsen (@dinoshauer)
- Sebastian Pipping (@hartwork)
- Helen Sherwood-Taylor (@helenst)
- Mocker (@Zuckonit)
- Tim Graham (@timgraham)
- Adam (@NorthIsUp)
- Norman Jäckel (@normanjaeckel)
- Derrick Petzold (@dpetzold)
- Michael van Tellingen (@mvantellingen)
- Patrick Yevsukov (@patrickyevsukov)
- Christer van der Meeren (@cmeeren)
- Timon Wong/NHNCN (@timonwong)
- Jeremy Dunck (@jdunck)
- Benjamin ABEL (@benjaminabel)
- Dan Baragan (@danbaragan)
- Rob Cowie (@robcowie)
- Amit Shah (@Amwam)
- Patrick Gerken (@do3cc)
- @dein0s
- David Stensland (@terite)
- Ankur Dedania (@AbsoluteMSTR)
- Lee Packham (@leepa)
- Jesse Mullan (@jmullan)
- Kwok-kuen Cheung (@cheungpat)
- Johan Bloemberg (@aequitas)
- Dan Watson (@dcwatson)
- Éric Araujo (@merwok)
- Dan Palmer (@danpalmer)
- Andy Boot (@bootandy)
- @m7v8
- John Vandenberg (@jayvdb)
- Adam Chainz (@adamchainz)
- @Brightcells
- Jonas Trappenberg (@teeberg)
- Andrew Konstantaras (@akonsta)
- Jason Brackman (@jasonbrackman) 
- Kathryn Lingel (@katlings)
- Andrew Gaul (@gaul)

Documenters
===================
- Reinout van Rees (@reinout)
- Helen Sherwood-Taylor (@helenst)
- Elliott Sales de Andrade (@QuLogic)
- Brian Peiris (@brianpeiris)
- Tim Graham (@timgraham)
- Josh Soref (@jsoref)

--------------------------------------------

A sincere thanks to everyone who has helped isort be the great utility it is today!
It would not be one-hundredth as useful and consistent as it is now without the help of your bug reports,
commits, and suggestions. You guys rock!

~Timothy Crosley
