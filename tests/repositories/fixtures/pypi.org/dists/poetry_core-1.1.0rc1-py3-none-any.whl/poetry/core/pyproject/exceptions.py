from __future__ import annotations

from poetry.core.exceptions import PoetryCoreException


class PyProjectException(PoetryCoreException):
    pass
